package com.is6144.envolveproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {
    private Button btn1paper;
    private Button btn1plastic;
    private Button btn1glass;
    private Button btn1waste;
    private Button btn1metal;
    private Button rtnMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);

        btn1paper = findViewById(R.id.btn1paper);
        btn1glass = findViewById(R.id.btn1glass);
        btn1plastic = findViewById(R.id.btn1plastic);
        btn1waste = findViewById(R.id.btn1waste);
        btn1metal = findViewById(R.id.btn1metal);
        rtnMain = findViewById(R.id.rtnMain);


        btn1glass.setOnClickListener(view -> {openglass();});
        btn1paper.setOnClickListener(view -> {openpaper();});
        btn1plastic.setOnClickListener(view -> {openplastic();});
        btn1waste.setOnClickListener(view -> {openwaste();});
        btn1metal.setOnClickListener(view -> {openmetal();});
        rtnMain.setOnClickListener(view -> {openMainActivity();});

    }

    public void openpaper() {
        Intent intent = new Intent(this, Paper.class);
        startActivity(intent);
    }

    public void openplastic() {
        Intent intent = new Intent(this, Plastic.class);
        startActivity(intent);
    }

    public void openglass() {
        Intent intent = new Intent(this, Glass.class);
        startActivity(intent);
    }

    public void openwaste() {
        Intent intent = new Intent(this, Waste.class);
        startActivity(intent);
    }

    public void openmetal() {
        Intent intent = new Intent(this, Metal.class);
        startActivity(intent);
    }

    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}