package com.is6144.envolveproject.model;

public class Recycling {
    private  String deviceId;
    private  String type;
    private  String supplier;
    private  String date;
    private  String quantity;
    private  String key;

    public Recycling() {
    }

    public Recycling(String deviceId, String type, String supplier, String date, String quantity, String key) {
        this.deviceId = deviceId;
        this.type = type;
        this.supplier = supplier;
        this.date = date;
        this.quantity = quantity;
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
