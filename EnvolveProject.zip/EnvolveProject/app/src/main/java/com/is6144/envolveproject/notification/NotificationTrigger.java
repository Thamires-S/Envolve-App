package com.is6144.envolveproject.notification;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.is6144.envolveproject.R;
import com.is6144.envolveproject.Reminders;

public class NotificationTrigger extends IntentService {

    private static Context cx;
    private static final String ALARM = "your.package.ALARM";

    public NotificationTrigger() {
        super("NotificationTrigger");
    }

    public static void starNotification(Context context) {
        cx = context;
        Intent intent = new Intent(context, NotificationTrigger.class);
        intent.setAction(ALARM);
        context.startService(intent);
    }


    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
//            if (ALARM.equals(action)) {
                handleAlarm();
//            }
        }
    }

    @SuppressLint("UnspecifiedImmutableFlag")
    private void handleAlarm() {

        PendingIntent notificationIntent = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            notificationIntent = PendingIntent.getActivity(this, 0, new Intent(this, Reminders.class), PendingIntent.FLAG_MUTABLE);
        }else {
            notificationIntent = PendingIntent.getActivity(this, 0, new Intent(this, Reminders.class), 0);

        }


        NotificationManager notificationManager = (NotificationManager) cx.getSystemService(Context.NOTIFICATION_SERVICE);

        int notificationId = 1;
        String channelId = "envolve-01";
        String channelName = "Envolve";
        int importance = NotificationManager.IMPORTANCE_HIGH;

        NotificationChannel mChannel = new NotificationChannel(
                channelId, channelName, importance);
        notificationManager.createNotificationChannel(mChannel);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(cx, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Envolve Alert")
                .setContentText("Reminder to put your bin outside");


        mBuilder.setContentIntent(notificationIntent);

        notificationManager.notify(notificationId, mBuilder.build());


    }


}