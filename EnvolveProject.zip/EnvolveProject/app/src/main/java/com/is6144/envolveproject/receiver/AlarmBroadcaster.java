package com.is6144.envolveproject.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.is6144.envolveproject.notification.NotificationTrigger;

public class AlarmBroadcaster extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //Remember in the SetAlarm file we made an intent to this, this is way this work, otherwise you would have to put an action
        //and here listen to the action, like in a normal receiver
        Log.e("houah", "yes");
        createNotification(context);

    }

    public void createNotification(Context context) {
        NotificationTrigger.starNotification(context);
    }

}