package com.is6144.envolveproject

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.util.Size
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LifecycleOwner
import com.awesomedialog.blennersilva.awesomedialoglibrary.AwesomeSuccessDialog
import com.awesomedialog.blennersilva.awesomedialoglibrary.interfaces.Closure
import com.google.common.util.concurrent.ListenableFuture
import com.google.mlkit.common.model.LocalModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.custom.CustomObjectDetectorOptions
import com.is6144.envolveproject.databinding.ActivityCameraDetectionBinding


class CameraDetectionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCameraDetectionBinding
    private lateinit var objectDetector: ObjectDetector
    private lateinit var cameraProviderFuture: ListenableFuture<ProcessCameraProvider>

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_camera_detection)

        cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            // get() is used to get the instance of the future.
            val cameraProvider = cameraProviderFuture.get()
            // Here, we will bind the preview
            bindPreview(cameraProvider = cameraProvider)

        }, ContextCompat.getMainExecutor(this))
        val localModel = LocalModel.Builder()
            .setAssetFilePath("object_detection.tflite")
            .build()


        val customObjectDetectorOptions =
            CustomObjectDetectorOptions.Builder(localModel)
                .setDetectorMode(CustomObjectDetectorOptions.STREAM_MODE)
                .enableClassification()
                .setClassificationConfidenceThreshold(0.5f)
                .setMaxPerObjectLabelCount(3)
                .build()

        objectDetector =
            ObjectDetection.getClient(customObjectDetectorOptions)
    }

    @SuppressLint("UnsafeOptInUsageError")
    @RequiresApi(Build.VERSION_CODES.R)
    private fun bindPreview(cameraProvider: ProcessCameraProvider) {
        val preview: Preview = Preview.Builder().build()
        preview.setSurfaceProvider(binding.previewView.surfaceProvider)

        val cameraSelector: CameraSelector = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .build()

        val point = Point()
        val size = display?.getRealSize(point)
        val imageAnalysis = ImageAnalysis.Builder()
            .setTargetResolution(Size(point.x, point.y))
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()

        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this)) { imageProxy ->
            val rotationDegrees = imageProxy.imageInfo.rotationDegrees
            val image = imageProxy.image
            if (image != null) {

                val inputImage = InputImage.fromMediaImage(image, rotationDegrees)
                objectDetector
                    .process(inputImage)
                    .addOnFailureListener {
                        imageProxy.close()
                    }.addOnSuccessListener { objects ->

                        for (i in objects) {
                            if (binding.layout.childCount > 1) binding.layout.removeViewAt(1)
                            val element = Draw(
                                this,
                                i.boundingBox,
                                i.labels.firstOrNull()?.text ?: "Undefined"
                            )
                            binding.layout.addView(element, 1)
                            if (i.labels.firstOrNull()?.text != null) {
                                AwesomeSuccessDialog(this)
                                    .setTitle("FOUND 1 OBJECT")
                                    .setMessage(i.labels.firstOrNull()?.text + "\n" + "Recyclable")
                                    .setColoredCircle(com.is6144.envolveproject.R.color.green)
                                    .setDialogIconAndColor(
                                        com.awesomedialog.blennersilva.awesomedialoglibrary.R.drawable.ic_dialog_info,
                                        R.color.white
                                    )
                                    .setCancelable(true)
                                    .setPositiveButtonText("Yes")
                                    .setPositiveButtonbackgroundColor(com.is6144.envolveproject.R.color.green)
                                    .setPositiveButtonTextColor(R.color.white)
//                                .setNegativeButtonText(getString(R.string.dialog_no_button))
//                                .setNegativeButtonbackgroundColor(R.color.dialogSuccessBackgroundColor)
                                    .setNegativeButtonTextColor(R.color.white)
                                    .setPositiveButtonClick {
                                      val intent = Intent(this@CameraDetectionActivity, Menu::class.java)
                                        startActivity(intent)
                                        finishAffinity()
                                    }
//                                .setNegativeButtonClick(Closure {
//                                    //click
//                                })
                                    .show()
                            }
                        }



                        imageProxy.close()
                    }
            }
        }

        cameraProvider.bindToLifecycle(
            this as LifecycleOwner,
            cameraSelector,
            imageAnalysis,
            preview
        )
    }
}