package com.is6144.envolveproject.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.is6144.envolveproject.RecycleActivity;
import com.is6144.envolveproject.databinding.CustomRecyclingLayoutBinding;
import com.is6144.envolveproject.model.Recycling;

import java.util.ArrayList;

public class RecyclingAdapter extends RecyclerView.Adapter<RecyclingAdapter.ViewHolder> {

    private Context context;
    ArrayList<Recycling> recyclingArrayList;
    RecyclingAdapter.OnItemClickListener mListener;


    public RecyclingAdapter(Context context, ArrayList<Recycling> recyclingArrayList) {

        this.context = context;
        this.recyclingArrayList = recyclingArrayList;
    }

    public interface OnItemClickListener {
        void onDeleteClick(Recycling recycling);
        void onEditClick(Recycling recycling);

    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        CustomRecyclingLayoutBinding binding = CustomRecyclingLayoutBinding
                .inflate(
                        LayoutInflater.from(parent.getContext()),
                        parent,
                        false);


        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Recycling recycling = recyclingArrayList.get(position);
        holder.bind(recycling);

    }


    @Override
    public int getItemCount() {
        return recyclingArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final CustomRecyclingLayoutBinding binding;

        public ViewHolder(CustomRecyclingLayoutBinding binding) {
            super(binding.getRoot());
            this.binding = binding;


            binding.deleteBtn.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Recycling home = recyclingArrayList.get(position);
                    mListener.onDeleteClick(home);
                }
            });

            binding.editBtn.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Recycling home = recyclingArrayList.get(position);
                    mListener.onEditClick(home);
                }
            });
        }

        public void bind(Recycling recycling) {
            Log.e("isdfa", recycling.getDate());
            binding.typeTv.setText(recycling.getType());
            binding.supplierTv.setText(recycling.getSupplier());
            binding.dateTv.setText(recycling.getDate());
            binding.quantityTv.setText(recycling.getQuantity()+ " KG");


        }
    }
}

