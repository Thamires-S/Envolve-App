package com.is6144.envolveproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.is6144.envolveproject.databinding.ActivityAddRecycleBinding;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class AddRecycleActivity extends AppCompatActivity {
    private ActivityAddRecycleBinding binding;
    private DatabaseReference recyclingRef;
    final Calendar myCalendar = Calendar.getInstance();
    private String deviceToken = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddRecycleBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        recyclingRef = FirebaseDatabase.getInstance().getReference("recycling");


        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            binding.quantityEt.setText(bundle.getString("quantity"));
            binding.typeEt.setText(bundle.getString("type"));
            binding.supplierEt.setText(bundle.getString("supplier"));
            binding.dateEt.setText(bundle.getString("date"));
            binding.saveBtn.setText("Update");
        }

        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();
                    deviceToken = String.valueOf(token);
                    // Log and toast
                    Log.d("tokenn", deviceToken);
                });

        DatePickerDialog.OnDateSetListener date = (view, year, month, day) -> {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, month);
            myCalendar.set(Calendar.DAY_OF_MONTH, day);
            String myFormat = "dd/MM/yyyy";
            SimpleDateFormat dateFormat = new SimpleDateFormat(myFormat, Locale.US);
            binding.dateEt.setText(dateFormat.format(myCalendar.getTime()));
        };
        binding.dateEt.setOnClickListener(v -> new DatePickerDialog(AddRecycleActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show());

        binding.saveBtn.setOnClickListener(view -> {
            if (binding.typeEt.getText().toString().isEmpty()) {
                binding.typeEt.setError("Please enter type");
                return;
            }
            if (binding.supplierEt.getText().toString().isEmpty()) {
                binding.supplierEt.setError("Please enter supplier");
                return;
            }
            if (binding.dateEt.getText().toString().isEmpty()) {
                binding.dateEt.setError("Please enter date");
                return;
            }
            if (binding.quantityEt.getText().toString().isEmpty()) {
                binding.quantityEt.setError("Please enter quantity");
                return;
            }
            if (binding.saveBtn.getText().toString().equals("Update")) {
                updateData(bundle.getString("deviceId"), bundle.getString("key"));

            } else {
                setRecyclingData();
            }
        });


    }

    private void updateData(String deviceId, String key) {
        binding.loading.setVisibility(View.VISIBLE);

        Map map = new HashMap();
        map.put("type", binding.typeEt.getText().toString());
        map.put("supplier", binding.supplierEt.getText().toString());
        map.put("date", binding.dateEt.getText().toString());
        map.put("quantity", binding.quantityEt.getText().toString());
        recyclingRef.child(deviceId).child(key).updateChildren(map)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        binding.loading.setVisibility(View.GONE);

                        Toast.makeText(this, "Updated Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AddRecycleActivity.this, RecycleActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        finish();
                    }
                });

    }

    private void setRecyclingData() {

        binding.loading.setVisibility(View.VISIBLE);

        String key = Objects.requireNonNull(recyclingRef.push().getKey());
        Map map = new HashMap();
        map.put("deviceId", deviceToken);
        map.put("type", binding.typeEt.getText().toString());
        map.put("supplier", binding.supplierEt.getText().toString());
        map.put("date", binding.dateEt.getText().toString());
        map.put("quantity", binding.quantityEt.getText().toString());
        map.put("key", key);
        recyclingRef.child(deviceToken).child(key).setValue(map)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        binding.loading.setVisibility(View.GONE);
                        Toast.makeText(this, "Added Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AddRecycleActivity.this, RecycleActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        finish();
                    }
                });


    }
}