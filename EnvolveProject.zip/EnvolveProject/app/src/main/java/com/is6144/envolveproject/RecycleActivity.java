package com.is6144.envolveproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.is6144.envolveproject.adapter.RecyclingAdapter;
import com.is6144.envolveproject.model.Recycling;

import java.util.ArrayList;

public class RecycleActivity extends AppCompatActivity implements RecyclingAdapter.OnItemClickListener {

    private RecyclerView recycleRv;
    private FloatingActionButton addRecycle;
    private String deviceToken = "";
    private DatabaseReference recyclingRef;
    private CircularProgressIndicator loading;
    private ArrayList<Recycling> recyclingArrayList = new ArrayList<>();
    private RecyclingAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle);

        recycleRv = findViewById(R.id.rv);
        addRecycle = findViewById(R.id.add_recycle);
        loading = findViewById(R.id.loading);
        recyclingRef = FirebaseDatabase.getInstance().getReference("recycling");


        addRecycle.setOnClickListener(view -> startActivity(new Intent(RecycleActivity.this, AddRecycleActivity.class)));

        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();
                    deviceToken = String.valueOf(token);
                    // Log and toast
                    Log.d("tokenn", deviceToken);
                    getRecyclingData();

                });


    }

    private void getRecyclingData() {
        recyclingArrayList.clear();
        loading.setVisibility(View.VISIBLE);
        recyclingRef.child(deviceToken)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        loading.setVisibility(View.GONE);

                        if (snapshot.exists()) {

                            for (DataSnapshot ds : snapshot.getChildren()) {
                                Recycling appointment = ds.getValue(Recycling.class);
                                recyclingArrayList.add(appointment);

                            }


                            mAdapter = new RecyclingAdapter(RecycleActivity.this, recyclingArrayList);
                            recycleRv.setLayoutManager(new LinearLayoutManager(RecycleActivity.this));
                            recycleRv.setAdapter(mAdapter);
                            mAdapter.setOnItemClickListener(RecycleActivity.this);

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        loading.setVisibility(View.GONE);

                    }
                });
    }


    @Override
    public void onDeleteClick(Recycling recycling) {

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Delete");
        alert.setMessage("Are you sure you want to delete?");
        alert.setPositiveButton(android.R.string.yes, (dialog, which) -> {
            // continue with delete
            recyclingRef.child(recycling.getDeviceId()).child(recycling.getKey()).removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    dialog.dismiss();
                    Toast.makeText(RecycleActivity.this, "Deleted Successfully", Toast.LENGTH_SHORT).show();

                    recreate();
                }
            });
        });
        alert.setNegativeButton(android.R.string.no, (dialog, which) -> {
            // close dialog
            dialog.cancel();
        });
        alert.show();

    }

    @Override
    public void onEditClick(Recycling data) {
        Intent intent = new Intent(RecycleActivity.this, AddRecycleActivity.class);
        intent.putExtra("deviceId",data.getDeviceId());
        intent.putExtra("type",data.getType());
        intent.putExtra("key",data.getKey());
        intent.putExtra("date",data.getDate());
        intent.putExtra("supplier",data.getSupplier());
        intent.putExtra("quantity",data.getQuantity());
        startActivity(intent);
    }
}