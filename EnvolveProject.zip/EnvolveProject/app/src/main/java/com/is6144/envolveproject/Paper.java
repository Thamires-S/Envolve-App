package com.is6144.envolveproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.is6144.envolveproject.model.RecyclingPoints;

import java.util.ArrayList;

public class Paper extends AppCompatActivity implements OnMapReadyCallback {

    private Button rtnbtnpaper;

    private ArrayList<RecyclingPoints> recyclingPoints = new ArrayList<>();

    private GoogleMap mMap;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paper);

//        Fragment fragment = new Map_Fragment();
//        getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, fragment).commit();
        recyclingPoints.add(new RecyclingPoints(51.92192831187437, -8.462963295871473));
        recyclingPoints.add(new RecyclingPoints(51.92319872810996, -8.459530068308647));
        recyclingPoints.add(new RecyclingPoints(51.909645767887646, -8.451290322157867));
        recyclingPoints.add(new RecyclingPoints(51.899478362865416, -8.493862343936893));
        recyclingPoints.add(new RecyclingPoints(51.885918242646724, -8.46570987792173));
        recyclingPoints.add(new RecyclingPoints(51.874473708280405, -8.490429116374068));
        recyclingPoints.add(new RecyclingPoints(51.88040827495439, -8.482189370223288));
        recyclingPoints.add(new RecyclingPoints(51.8761693786882, -8.526821328540011));
        recyclingPoints.add(new RecyclingPoints(51.88695427974968, -8.461728610471004));
        recyclingPoints.add(new RecyclingPoints(51.91610215137924, -8.497616706466715));
        recyclingPoints.add(new RecyclingPoints(51.82272503889052, -8.389492226027022));
        recyclingPoints.add(new RecyclingPoints(51.84860681083034, -8.357219886936468));
        recyclingPoints.add(new RecyclingPoints(51.850727607924, -8.368892860650071));
        recyclingPoints.add(new RecyclingPoints(51.884222939904724, -8.53780765674105));
        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.MY_MAP);
        mapFragment.getMapAsync(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        rtnbtnpaper = (Button) findViewById(R.id.rtnMainMenu);
        rtnbtnpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity2();
            }
        });
    }

    public void openMainActivity2() {
        Intent intent = new Intent(this, Menu.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);

            return;
        }

        mMap.setMyLocationEnabled(true);

        fusedLocationClient.getLastLocation()
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        Location lastLocation = task.getResult();
                        LatLng currentLocation = new LatLng(lastLocation.getLatitude(),
                                lastLocation.getLongitude());
                        mMap.addMarker(new MarkerOptions().position(currentLocation).title("Current Location"));
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 12f));

                        for (int i = 0; i < recyclingPoints.size(); i++) {

                            // below line is use to add marker to each location of our array list.
                            LatLng latLng1 = new LatLng(recyclingPoints.get(i).getLatitude(), recyclingPoints.get(i).getLongitude());
                            googleMap.addMarker(new MarkerOptions().position(latLng1).title("Recycling Point"));

                        }

                    } else {
                        Log.w("MapsActivity", "getLastLocation:exception", task.getException());
                        Toast.makeText(Paper.this, "Unable to get location", Toast.LENGTH_SHORT).show();
                    }
                });
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    onMapReady(mMap);
                }
            }
        }
    }
}